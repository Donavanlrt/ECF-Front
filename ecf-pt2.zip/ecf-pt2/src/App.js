import axios from 'axios';
import './App.css';
import React from 'react';
import Menu from './Menu';
import meals from './meals';

class App extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        selectedMeals: '',
      }
    }

    componentDidMount() {
        this.loadMeals();
      }

      loadMeals = () => {
        axios.get('http://localhost:3000').then (response => this.setState ({ meals: response.data}));
      }
    }

    render() {
        if (this.state.loading) {
          return <div className="container"><Loader /></div>;
        }
    }

export default App;
