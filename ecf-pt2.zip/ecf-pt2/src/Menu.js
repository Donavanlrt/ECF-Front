import React from 'react';
import meals from './meals';

<div class="container">
    <h1 class="decouvreznotre">Découvrez notre</h1>
    <h1 class="menu">menu.</h1>
</div>

class Menu extends React.Component {
    render() {
        return (
            <div className="mealss">
            <img src={this.props.meals.imageSrc} alt={this.props.meal.title}/>

            

            </div>
        )
    }
}